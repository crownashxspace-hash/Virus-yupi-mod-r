package dev.yupi.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class YupiSettings {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("yupi-client.json");

    public static boolean masterEnabled = true;
    public static boolean autoMine = false;
    public static boolean autoHome = false;
    public static boolean autoSell = false;
    public static boolean lowHealthAlert = true;
    public static boolean showNotifications = true;
    public static int searchRange = 16;
    public static int lowHealthHearts = 3;
    public static String homeCommand = "home 1";
    public static String sellCommand = "sell metal";

    private YupiSettings() {}

    private static final class Data {
        boolean masterEnabled = true;
        boolean autoMine = false;
        boolean autoHome = false;
        boolean autoSell = false;
        boolean lowHealthAlert = true;
        boolean showNotifications = true;
        int searchRange = 16;
        int lowHealthHearts = 3;
        String homeCommand = "home 1";
        String sellCommand = "sell metal";
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            Data d = GSON.fromJson(Files.readString(FILE), Data.class);
            if (d == null) return;
            masterEnabled = d.masterEnabled;
            autoMine = d.autoMine;
            autoHome = d.autoHome;
            autoSell = d.autoSell;
            lowHealthAlert = d.lowHealthAlert;
            showNotifications = d.showNotifications;
            searchRange = Math.max(4, Math.min(64, d.searchRange));
            lowHealthHearts = Math.max(1, Math.min(10, d.lowHealthHearts));
            homeCommand = d.homeCommand == null ? "home 1" : d.homeCommand;
            sellCommand = d.sellCommand == null ? "sell metal" : d.sellCommand;
        } catch (Exception ignored) {
            // Invalid config is ignored; defaults remain active.
        }
    }

    public static void save() {
        Data d = new Data();
        d.masterEnabled = masterEnabled;
        d.autoMine = autoMine;
        d.autoHome = autoHome;
        d.autoSell = autoSell;
        d.lowHealthAlert = lowHealthAlert;
        d.showNotifications = showNotifications;
        d.searchRange = searchRange;
        d.lowHealthHearts = lowHealthHearts;
        d.homeCommand = homeCommand;
        d.sellCommand = sellCommand;
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(d));
        } catch (IOException ignored) {
        }
    }
}
