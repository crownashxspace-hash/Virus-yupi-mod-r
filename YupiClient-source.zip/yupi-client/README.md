# Yupi Client — proyecto base Fabric

Este paquete es el **código fuente** de una primera base de la GUI de Yupi Client.

## Incluye
- Pantalla oscura con acentos morados.
- Tecla Inicio/Home para abrir y cerrar el menú.
- Interruptores visuales para los módulos y preferencias.
- Guardado de preferencias en `config/yupi-client.json`.
- Objetivo de Minecraft Java 1.21.11.

## Importante
Los botones de Auto Mine, Auto Home y Auto Sell son actualmente **ajustes de interfaz**, no automatizaciones implementadas. No se presenta como un `.jar` compilado ni probado. La combinación exacta de versiones debe comprobarse al compilar.

Minecraft 1.21.11 usa la línea de herramientas Fabric Loom 1.14 y el proyecto usa Yarn para esa versión. Si Gradle indica que una versión concreta de Yarn o Fabric API no existe, actualiza esos valores desde la página oficial de Fabric antes de compilar.

## Compilar
Necesitas Java 21 y Gradle instalado.

Desde la carpeta del proyecto:
```bash
gradle build
```

Si compila correctamente, el `.jar` instalable estará en:
`build/libs/yupi-client-1.0.0.jar`

Copia el `.jar` a la carpeta `mods` de tu perfil Fabric, junto con Fabric API.
