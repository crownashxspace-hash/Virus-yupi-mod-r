package dev.yupi.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class YupiScreen extends Screen {
    private int panelX, panelY, panelW, panelH;

    public YupiScreen() {
        super(Text.literal("Yupi Client"));
    }

    @Override
    protected void init() {
        panelW = Math.min(760, this.width - 28);
        panelH = Math.min(440, this.height - 28);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        int leftX = panelX + 18;
        int rightX = panelX + panelW / 2 + 8;
        int buttonW = panelW / 2 - 34;
        int y = panelY + 94;

        addDrawableChild(ButtonWidget.builder(toggle("Mod activado", YupiSettings.masterEnabled),
                b -> { YupiSettings.masterEnabled = !YupiSettings.masterEnabled; YupiSettings.save(); rebuild(); })
                .dimensions(leftX, y, buttonW, 26).build());

        addDrawableChild(ButtonWidget.builder(toggle("Auto Mine", YupiSettings.autoMine),
                b -> { YupiSettings.autoMine = !YupiSettings.autoMine; YupiSettings.save(); rebuild(); })
                .dimensions(leftX, y + 34, buttonW, 26).build());

        addDrawableChild(ButtonWidget.builder(toggle("Auto Home", YupiSettings.autoHome),
                b -> { YupiSettings.autoHome = !YupiSettings.autoHome; YupiSettings.save(); rebuild(); })
                .dimensions(leftX, y + 68, buttonW, 26).build());

        addDrawableChild(ButtonWidget.builder(toggle("Auto Sell", YupiSettings.autoSell),
                b -> { YupiSettings.autoSell = !YupiSettings.autoSell; YupiSettings.save(); rebuild(); })
                .dimensions(rightX, y, buttonW, 26).build());

        addDrawableChild(ButtonWidget.builder(toggle("Alerta de poca vida", YupiSettings.lowHealthAlert),
                b -> { YupiSettings.lowHealthAlert = !YupiSettings.lowHealthAlert; YupiSettings.save(); rebuild(); })
                .dimensions(rightX, y + 34, buttonW, 26).build());

        addDrawableChild(ButtonWidget.builder(toggle("Notificaciones", YupiSettings.showNotifications),
                b -> { YupiSettings.showNotifications = !YupiSettings.showNotifications; YupiSettings.save(); rebuild(); })
                .dimensions(rightX, y + 68, buttonW, 26).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Rango de búsqueda: " + YupiSettings.searchRange),
                b -> { YupiSettings.searchRange = YupiSettings.searchRange >= 64 ? 8 : YupiSettings.searchRange + 8; YupiSettings.save(); rebuild(); })
                .dimensions(leftX, y + 112, buttonW, 26).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Vida mínima: " + YupiSettings.lowHealthHearts + " corazones"),
                b -> { YupiSettings.lowHealthHearts = YupiSettings.lowHealthHearts >= 10 ? 1 : YupiSettings.lowHealthHearts + 1; YupiSettings.save(); rebuild(); })
                .dimensions(rightX, y + 112, buttonW, 26).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Cerrar"), b -> close())
                .dimensions(panelX + panelW - 94, panelY + panelH - 36, 76, 22).build());
    }

    private Text toggle(String name, boolean on) {
        return Text.literal(name + "  [" + (on ? "ACTIVADO" : "DESACTIVADO") + "]");
    }

    private void rebuild() {
        clearChildren();
        init();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        panelW = Math.min(760, this.width - 28);
        panelH = Math.min(440, this.height - 28);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF20A0D1A);
        context.fill(panelX, panelY, panelX + panelW, panelY + 3, 0xFF8B5CFF);
        context.drawText(this.textRenderer, "Yupi Client", panelX + 20, panelY + 18, 0xFFB88CFF, false);
        context.drawText(this.textRenderer, "Tu mundo, tu configuración.", panelX + 20, panelY + 38, 0xFFB4B9E8, false);
        context.drawText(this.textRenderer, "INICIO  /  AUTOMATIZACIÓN  /  AJUSTES", panelX + 20, panelY + 66, 0xFF777FAE, false);
        context.drawText(this.textRenderer, "Los interruptores guardan sus preferencias.", panelX + 20, panelY + panelH - 28, 0xFF777FAE, false);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        YupiSettings.save();
        if (this.client != null) this.client.setScreen(null);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
